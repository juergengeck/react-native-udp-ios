import { type Spec } from './NativeUDPDirectModule';
declare const _default: Spec;
export default _default;
export type { Spec as UDPDirectModuleSpec, UdpSocketOptionsSpec, BindInfoSpec, SendOptionsSpec, } from './NativeUDPDirectModule';
export declare const UDP_EVENTS: {
    readonly MESSAGE: "onMessage";
    readonly ERROR: "onError";
    readonly CLOSE: "onClose";
};
export { UDPSocketJSI, createUDPSocket, isJSIAvailable, type UDPSocketOptions, type UDPMessageEvent, type UDPErrorEvent, type UDPCloseEvent } from './jsi-wrapper';
//# sourceMappingURL=index.d.ts.map