/**
 * JSI Wrapper for UDP Direct Module
 *
 * This file provides a clean JavaScript interface to the JSI-based UDP functions.
 * It uses the global functions installed by UDPDirectJSI.
 */
declare global {
    function udpSendDirect(socketId: string, buffer: ArrayBuffer, offset: number, length: number, port: number, address: string): void;
    const _udpJSI: {
        createSocket(options: {
            type?: string;
            reuseAddr?: boolean;
            broadcast?: boolean;
        }): string;
        bind(socketId: string, port: number, address: string): void;
        close(socketId: string): void;
        setEventHandler(socketId: string, handlers: {
            onMessage?: (event: {
                socketId: string;
                data: ArrayBuffer;
                base64Data?: string;
                address: string;
                port: number;
            }) => void;
            onError?: (event: {
                socketId: string;
                error: string;
            }) => void;
            onClose?: (event: {
                socketId: string;
                error?: string;
            }) => void;
        }): void;
    };
}
export interface UDPSocketOptions {
    type?: 'udp4' | 'udp6';
    reuseAddr?: boolean;
    broadcast?: boolean;
}
export interface UDPMessageEvent {
    socketId: string;
    data: ArrayBuffer;
    base64Data?: string;
    address: string;
    port: number;
}
export interface UDPErrorEvent {
    socketId: string;
    error: string;
}
export interface UDPCloseEvent {
    socketId: string;
    error?: string;
}
/**
 * High-performance UDP socket class using JSI bindings
 */
export declare class UDPSocketJSI {
    private socketId;
    private handlers;
    /**
     * Create a new UDP socket
     */
    create(options?: UDPSocketOptions): Promise<void>;
    /**
     * Bind the socket to a port and address
     */
    bind(port: number, address?: string): Promise<void>;
    /**
     * Send data using zero-copy transfer
     */
    send(data: Uint8Array | ArrayBuffer, port: number, address: string): Promise<void>;
    /**
     * Set event handlers
     */
    on(event: 'message', handler: (event: UDPMessageEvent) => void): void;
    on(event: 'error', handler: (event: UDPErrorEvent) => void): void;
    on(event: 'close', handler: (event: UDPCloseEvent) => void): void;
    /**
     * Close the socket
     */
    close(): Promise<void>;
    private updateEventHandlers;
}
/**
 * Utility function to check if JSI bindings are available
 */
export declare function isJSIAvailable(): boolean;
/**
 * Create a UDP socket using JSI bindings
 *
 * @example
 * ```typescript
 * const socket = await createUDPSocket({ broadcast: true });
 * await socket.bind(12345);
 *
 * socket.on('message', (event) => {
 *   console.log(`Received from ${event.address}:${event.port}`);
 *   // Zero-copy access to received data
 *   const data = new Uint8Array(event.data);
 *   console.log('Data:', new TextDecoder().decode(data));
 * });
 *
 * // Zero-copy send
 * const message = new TextEncoder().encode('Hello UDP!');
 * await socket.send(message, 12345, '192.168.1.255');
 * ```
 */
export declare function createUDPSocket(options?: UDPSocketOptions): Promise<UDPSocketJSI>;
//# sourceMappingURL=jsi-wrapper.d.ts.map