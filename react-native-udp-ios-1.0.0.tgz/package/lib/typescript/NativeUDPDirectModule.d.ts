import type { TurboModule } from 'react-native/Libraries/TurboModule/RCTExport';
export interface UdpSocketOptionsSpec {
    type: string;
    reuseAddr: boolean;
    reusePort?: boolean;
    broadcast: boolean;
    debug?: boolean;
    debugLabel?: string;
    direct?: boolean;
}
export interface BindInfoSpec {
    address: string;
    port: number;
}
export interface SendOptionsSpec {
    timeout?: number;
    ttl?: number;
}
export interface Spec extends TurboModule {
    createSocket(options: UdpSocketOptionsSpec): Promise<{
        socketId: string;
    }>;
    bind(socketId: string, port: number, address: string): Promise<BindInfoSpec>;
    close(socketId: string): Promise<void>;
    closeAllSockets(): Promise<{
        closed: number;
    }>;
    send(socketId: string, base64Data: string, port: number, address: string, options?: SendOptionsSpec): Promise<void>;
    getLocalIPAddresses(): string[];
    address(socketId: string): Promise<{
        address: string;
        port: number;
        family: string;
        bound?: boolean;
    }>;
    setBroadcast(socketId: string, flag: boolean): Promise<void>;
    setDataEventHandler(socketId: string): Promise<void>;
    forciblyReleasePort?(port: number): Promise<{
        success: boolean;
    }>;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
    getConstants(): {
        VERSION: string;
        TURBO_ENABLED: boolean;
    };
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeUDPDirectModule.d.ts.map